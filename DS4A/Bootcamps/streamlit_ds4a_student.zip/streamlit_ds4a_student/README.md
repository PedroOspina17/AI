# streamlit_ds4a

Este es un tutorial corto de cómo usar Streamlit para crear dashboards sencillos.

Debe tener instalado streamlit, pandas y plotly. Para instalar streamlit, use el comando `pip install streamlit` (o `pip3` en otros sistemas). En Windows, Streamlit puede ser instalado en Anaconda ([instrucciones](https://docs.streamlit.io/en/stable/troubleshooting/clean-install.html))

Luego abra una terminal en el directorio de la aplicación y corra:

    streamlit run app.py

El navegador por defecto se abrirá mostrando la aplicación. Si esto no es así, entre desde su navegador a la dirección que le sugiere la terminal.