import streamlit as st
import plotly.express as px
import pandas as pd
pd.options.plotting.backend = "plotly"

