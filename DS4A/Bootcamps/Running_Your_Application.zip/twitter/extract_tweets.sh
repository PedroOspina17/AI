cd ~
python36 twitter/main.py
