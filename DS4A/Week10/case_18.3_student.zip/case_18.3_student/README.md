Set up instructions
If you are using Docker run the following commands:
```
pip install -U pip
pip install --upgrade -r path/to/requirements.txt
```
If you are using Windows and have issues going through your normal `pip install -r path/to/requirements.txt`
refer to the `win-environment-loading.pdf` and use the `win_env.yml`.
